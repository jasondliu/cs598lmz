import types
# Test types.FunctionType
