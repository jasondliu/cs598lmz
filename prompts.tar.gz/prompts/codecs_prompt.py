import codecs
# Test codecs.register_error
