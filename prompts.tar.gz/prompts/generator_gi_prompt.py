gi = (i for i in ())
# Test gi.gi_code
