from types import FunctionType
a = (x for x in [1])
