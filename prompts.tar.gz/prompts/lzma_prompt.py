import lzma
# Test LZMADecompressor
