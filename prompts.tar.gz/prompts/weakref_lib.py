import weakref
