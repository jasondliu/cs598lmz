from _struct import Struct
s = Struct.__new__(Struct)
