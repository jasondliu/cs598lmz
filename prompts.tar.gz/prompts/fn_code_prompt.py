fn = lambda: None
# Test fn.__code__
