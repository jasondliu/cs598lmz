import sys, threading
threading.Thread(target=lambda:
