import ctypes
FUNTYPE = ctypes.CFUNCTYPE(
