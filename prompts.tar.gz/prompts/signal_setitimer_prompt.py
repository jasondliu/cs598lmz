import signal
# Test signal.setitimer
