import ctypes
ctypes.cast(
