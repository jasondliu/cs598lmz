import mmap
# Test mmap.mmap
