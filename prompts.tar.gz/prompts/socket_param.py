import socket
socket.if_indextoname(
