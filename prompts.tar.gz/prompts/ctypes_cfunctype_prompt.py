import ctypes
# Test ctypes.CFUNCTYPE
