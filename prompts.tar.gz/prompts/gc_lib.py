import gc, weakref
