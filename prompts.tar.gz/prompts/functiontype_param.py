from types import FunctionType
list(FunctionType(
