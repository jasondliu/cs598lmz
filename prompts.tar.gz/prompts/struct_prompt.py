import _struct
# Test _struct.Struct
