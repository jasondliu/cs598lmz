import _struct
