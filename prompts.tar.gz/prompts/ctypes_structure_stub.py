import ctypes

class S(ctypes.Structure):
    x =
