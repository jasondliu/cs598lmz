import codecs
codecs.register_error(
