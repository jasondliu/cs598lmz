import weakref
# Test weakref.ref
