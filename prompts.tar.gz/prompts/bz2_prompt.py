import bz2
# Test BZ2Decompressor
