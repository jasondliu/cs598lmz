import io
# Test io.RawIOBase
