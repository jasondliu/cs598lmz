import codecs
codecs
