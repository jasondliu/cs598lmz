import select
# Test select.select
