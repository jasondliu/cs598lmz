import ctypes
# Test ctypes.CField
